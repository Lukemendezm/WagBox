import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { useRouter } from "next/router";

export default function DogBoxPage() {
  const [tier, setTier] = useState("tier1");
  const [coupon, setCoupon] = useState("");
  const router = useRouter();

  const tierDetails = {
    tier1: {
      price: 35,
      description:
        "For 1 dog: 2 packs of poop bags, 2 squeaky toys, 1 bag of treats, pet wipes, and 1 pack of vitamins/probiotics/calming chews."
    },
    tier2: {
      price: 75,
      description:
        "For 2-3 dogs: Everything in Tier 1 multiplied accordingly for 2-3 dogs."
    },
    tier3: {
      price: 100,
      description:
        "For 4+ dogs: Everything in Tier 1 multiplied for 4+ dogs."
    }
  };

  const handleCheckout = async () => {
    const res = await fetch("/api/checkout", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        tier,
        price: tierDetails[tier].price,
        coupon
      })
    });
    const data = await res.json();
    router.push(data.url);
  };

  return (
    <div className="min-h-screen p-6 bg-orange-50 text-gray-800 font-sans bg-[url('/dog-paws-bg.png')] bg-cover">
      <div className="max-w-4xl mx-auto bg-white/90 p-8 rounded-2xl shadow-xl">
        <h1 className="text-5xl font-bold mb-4 text-center text-orange-700">WAG BOX</h1>
        <p className="mb-6 text-lg text-center">
          A monthly subscription box that fits all of your dog's needs. New toys and
          treats every month. Free outfits for each dog on their birthday and for
          upcoming holidays.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          {Object.entries(tierDetails).map(([key, { price, description }]) => (
            <Card
              key={key}
              className={`cursor-pointer bg-orange-100 hover:bg-orange-200 transition ${
                tier === key ? "ring-4 ring-orange-500" : ""
              }`}
              onClick={() => setTier(key)}
            >
              <CardContent className="p-4">
                <h2 className="text-2xl font-semibold mb-2">${price} / month</h2>
                <p className="text-sm">{description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mb-6">
          <h3 className="text-xl font-semibold mb-2">Customize your box</h3>
          <p className="text-sm mb-2">
            You may double up on any item instead of receiving all items.
          </p>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {["Poop Bags", "Toys", "Treats", "Wipes", "Supplements"].map((item) => (
              <div key={item} className="flex items-center space-x-2">
                <Checkbox id={item} />
                <Label htmlFor={item}>Double {item}</Label>
              </div>
            ))}
          </div>
        </div>

        <div className="mb-6">
          <Label htmlFor="ambassador" className="block mb-1">
            Have a discount code?
          </Label>
          <Input
            id="ambassador"
            placeholder="Enter code here"
            className="w-full"
            value={coupon}
            onChange={(e) => setCoupon(e.target.value)}
          />
        </div>

        <Button className="w-full bg-orange-500 hover:bg-orange-600 text-white" onClick={handleCheckout}>
          Subscribe Now
        </Button>

        <div className="mt-6 text-center text-sm text-gray-600">
          Already subscribed? <a href="/login" className="text-orange-700 font-medium">Log in</a>
        </div>
      </div>
    </div>
  );
}
